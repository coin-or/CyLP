import numpy as np

EPSILON = 0.00000001
IOFILE = 'qpgenprob2'
DATATYPE = np.double
